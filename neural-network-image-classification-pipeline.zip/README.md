# Neural Network Image Classification Pipeline Verification

A notebook-based project comparing baseline Feedforward Neural Networks (FNN/MLP) and Convolutional Neural Networks (CNN) using TensorFlow and PyTorch on MNIST and Fashion-MNIST.

## Objectives
- Load and preprocess benchmark image datasets
- Normalize image pixel values
- Train FNN and CNN baselines with gradient-based optimization
- Verify backpropagation by checking gradients
- Record loss and accuracy metrics
- Visualize training curves and predictions

## Notebook
Open `Neural_Network_Image_Classification_Pipeline_Verification.ipynb` in Jupyter or Google Colab.

## Environment
Recommended: Google Colab or local Python 3.10+ with GPU optional.

Install dependencies:
```bash
pip install -r requirements.txt
```

Datasets are downloaded by the Keras and torchvision APIs during notebook execution.

## Experiments
The notebook contains training/evaluation cells for:
- TensorFlow FNN on MNIST
- TensorFlow CNN on MNIST
- TensorFlow FNN on Fashion-MNIST
- TensorFlow CNN on Fashion-MNIST
- PyTorch FNN on MNIST
- PyTorch CNN on MNIST
- PyTorch FNN on Fashion-MNIST
- PyTorch CNN on Fashion-MNIST

## Backpropagation verification
A PyTorch sanity-check cell computes loss, calls `loss.backward()`, and verifies that trainable parameters have finite, non-zero gradients. This verifies gradient flow (not a formal finite-difference gradient check).

## Outputs
Training cells display training loss/accuracy, test metrics, learning curves, and visual predictions. Metrics are produced by running the notebook; do not report unexecuted values.

## Notes
Training time depends on hardware and number of samples/epochs. The notebook uses a subset for faster experimentation. Increase `train_limit`, `test_limit`, and epochs for more thorough training.
